# Gia Phả App Icons

Generated directly from vector (SVG) source — `icon-source.svg` and
`icon-maskable-source.svg` are included in this folder so you (or Claude
Code) can re-export at any size later, or hand-edit the design (colors,
shape) without starting over.

Place this whole `icons` folder into your app's `public/` directory (so
files end up at `/icons/...` when served).

## 1. Add these tags to `index.html` `<head>`

```html
<!-- iOS home screen icon -->
<link rel="apple-touch-icon" href="/icons/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="57x57" href="/icons/apple-touch-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/icons/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/icons/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/icons/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/icons/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/icons/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/icons/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/icons/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="167x167" href="/icons/apple-touch-icon-167x167.png">
<link rel="apple-touch-icon" sizes="180x180" href="/icons/apple-touch-icon-180x180.png">

<!-- Makes the app run full-screen (no Safari chrome) when launched from the home screen -->
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Gia Phả">

<!-- Favicons -->
<link rel="icon" type="image/png" sizes="32x32" href="/icons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/icons/favicon-16x16.png">
<link rel="shortcut icon" href="/icons/favicon.ico">
```

## 2. `manifest.json` — required for Android install (iOS ignores this file)

Android's "Add to Home Screen" / install prompt reads this file directly, so
unlike iOS it needs more than just the icons array — `name`, `display`, and
`theme_color`/`background_color` all factor into whether Chrome considers
the app installable at all.

If using `vite-plugin-pwa`, put this under the `manifest` key in your Vite
config (or as a standalone `manifest.json` if not using the plugin):

```json
{
  "name": "Gia Phả",
  "short_name": "Gia Phả",
  "description": "Sổ gia phả gia đình — cây phả hệ và lịch sử dòng họ",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#5C121E",
  "theme_color": "#7A1A27",
  "icons": [
    { "src": "/icons/icon-192x192.png", "sizes": "192x192", "type": "image/png", "purpose": "any" },
    { "src": "/icons/icon-512x512.png", "sizes": "512x512", "type": "image/png", "purpose": "any" },
    { "src": "/icons/icon-maskable-192x192.png", "sizes": "192x192", "type": "image/png", "purpose": "maskable" },
    { "src": "/icons/icon-maskable-512x512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable" }
  ]
}
```

Also add this to `index.html` `<head>` so Chrome tints the address bar /
task switcher to match the icon's maroon background on Android:

```html
<meta name="theme-color" content="#7A1A27">
```

### Android install checklist

Beyond the manifest, Chrome only offers the install prompt if all of these
are true — worth checking if "Add to Home Screen" doesn't appear:

- Served over HTTPS (Cloudflare Workers & Pages gives you this by default)
- A registered service worker exists (handled by `vite-plugin-pwa`)
- The manifest includes at least one 192px and one 512px icon (included
  above) and `display` is `standalone` or `fullscreen`

## Re-exporting from the vector source

Every PNG here was rasterized straight from the SVG at its target
resolution (not scaled down from one bitmap), so edges stay crisp even at
16x16. To regenerate after editing the SVG, using `rsvg-convert`:

```bash
rsvg-convert -w 180 -h 180 icon-source.svg -o apple-touch-icon-180x180.png
```

Swap in whatever size you need. Apple-touch-icons must stay opaque
(no transparency) — flatten to RGB after rasterizing, e.g. with:

```bash
python3 -c "from PIL import Image; Image.open('file.png').convert('RGB').save('file.png')"
```

## Notes

- iOS ignores `manifest.json` icons — it only uses `apple-touch-icon`
  links, which is why both sets are included.
- iOS applies its own rounded-corner mask on top of these icons — don't
  pre-round the corners, or you'll get double rounding.
- The "maskable" source (`icon-maskable-source.svg`) has the tree scaled
  down with extra padding so Android/iOS adaptive-icon shapes don't clip it.
